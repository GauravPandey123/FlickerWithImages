package com.example.medrait.model;


public class ContentModel
        extends BaseModel {

    @SuppressWarnings("membername")
    public String _content;

    @Override
    public String toString() {
        return _content;
    }

}