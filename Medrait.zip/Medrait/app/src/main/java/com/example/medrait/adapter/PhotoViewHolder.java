package com.example.medrait.adapter;

import android.view.View;
import android.widget.ImageView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.medrait.R;
import butterknife.BindView;
import butterknife.ButterKnife;


public class PhotoViewHolder
        extends RecyclerView.ViewHolder {

    @BindView(R.id.image)
    protected ImageView image;

    public PhotoViewHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
    }

}