package com.example.medrait.model;


public class OwnerModel
        extends BaseModel {

    public String username;

    @Override
    public String toString() {
        return username;
    }

}