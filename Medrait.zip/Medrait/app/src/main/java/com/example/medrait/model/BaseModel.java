package com.example.medrait.model;

import java.io.Serializable;


public class BaseModel
        implements Serializable {

}