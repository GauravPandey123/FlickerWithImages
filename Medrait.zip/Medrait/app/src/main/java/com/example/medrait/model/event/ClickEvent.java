package com.example.medrait.model.event;


public class ClickEvent {
}